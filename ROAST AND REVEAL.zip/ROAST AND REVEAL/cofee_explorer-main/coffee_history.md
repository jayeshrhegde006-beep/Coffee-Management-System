![Roast & Revel Background](app_background.png)

# The Complete History of Coffee

## Ancient Origins: The Discovery of Coffee

### The Ethiopian Legend (9th Century CE)

The most popular origin story of coffee centers on **Kaldi**, an Ethiopian goat herder in the 9th century. According to legend, Kaldi noticed his goats became energetic and refused to sleep after eating bright red berries from a certain tree. Intrigued, he tried the berries himself and experienced a similar energizing effect.

Kaldi brought the berries to a local monastery, where a monk threw them into a fire, disapproving of their use. The roasting beans produced an enticing aroma that led the monks to retrieve them from the flames, grind them up, and dissolve them in hot water—creating the world's first cup of coffee.

### Early Ethiopian Coffee Culture

While the Kaldi legend is charming, the actual history of coffee in Ethiopia likely predates the 9th century. The **Oromo people** of Ethiopia are believed to have been the first to recognize the energizing effect of the coffee plant. They would mix ground coffee beans with animal fat to create energy balls for long journeys—an early form of the energy bar.

Coffee grew wild in the forests of southwestern Ethiopia, particularly in the **Kaffa region** (from which coffee may derive its name). The plant, *Coffea arabica*, was indigenous to these highland forests, growing beneath the forest canopy.

### The Yemeni Connection (15th Century)

Coffee cultivation and consumption as a beverage began in **Yemen** around the 15th century. Sufi monks in Yemen drank coffee to stay awake during long hours of prayer and meditation. The port of **Al Mukha** (Mocha) became the first major coffee trading center, giving its name to the mocha coffee we know today.

Yemeni farmers developed sophisticated agricultural techniques:
- Terraced farming on mountainsides
- Shade-grown cultivation methods
- The first processing techniques (natural/dry method)
- Selective breeding of coffee plants

## The Spread Through the Islamic World (15th-16th Centuries)

### Ottoman Empire and Coffee Houses

Coffee reached **Mecca** and **Medina** in the early 16th century, then spread throughout the Ottoman Empire. **Constantinople (Istanbul)** opened its first coffee house in **1554**, called a *qahveh khaneh*.

These coffee houses became:
- Centers of social activity and communication
- Places for intellectual discussion, chess, and music
- Sometimes called "Schools of the Wise"
- Venues for political discussion (which occasionally led to their closure by authorities)

### The Coffee Controversy

Coffee faced religious controversy in Islamic societies:
- **1511**: The Governor of Mecca banned coffee, claiming it stimulated radical thinking
- **1524**: The ban was overturned by Sultan Selim I, a coffee enthusiast
- Scholars debated whether coffee was permissible under Islamic law
- Eventually, coffee was deemed acceptable as it was not technically intoxicating

## Coffee Arrives in Europe (16th-17th Centuries)

### Initial Introduction

Coffee reached Europe through various routes:
- **1570s**: Venetian merchants brought coffee to Venice from the Ottoman Empire
- **1600s**: Coffee arrived in Holland, brought by Dutch traders
- **1615**: Coffee reached Venice officially, sparking religious debate
- **1645**: The first European coffee house opened in Venice

### The Pope's Coffee (1600)

When coffee first arrived in Europe, some Catholic clergy called it the "bitter invention of Satan" and pressured Pope Clement VIII to ban it. According to legend, the Pope decided to taste it before making a decree. Finding it delicious, he declared: "This devil's drink is so delicious, we should cheat the devil by baptizing it!"

### The Birth of European Coffee Houses

European coffee houses became vital cultural institutions:

**England (1650s)**
- First coffee house in Oxford (1650)
- London's first coffee house (1652) at St. Michael's Alley
- "Penny Universities" - pay a penny for coffee and conversation
- Lloyd's Coffee House became Lloyd's of London insurance company
- The London Stock Exchange began in Jonathan's Coffee House

**France (1670s)**
- Café Procope in Paris (1686), still operating today
- Meeting place for Enlightenment philosophers: Voltaire, Rousseau, Diderot
- Became centers of French literary and political life
- Key venues during the French Revolution

**Austria (1683)**
- First Viennese coffee house opened after the **Battle of Vienna**
- Legend says Franz Georg Kolschitzky found abandoned coffee sacks left by retreating Ottoman army
- Created the Viennese coffee house tradition
- Introduced the practice of filtering coffee and adding milk

**Germany (1670s)**
- First coffee houses in Bremen and Hamburg
- Coffee became associated with Enlightenment thinking
- Bach composed the "Coffee Cantata" (1732) satirizing coffee addiction

### Coffee vs. Tea: The Great Debate

In Britain, a cultural divide developed:
- Coffee was associated with business, commerce, and men
- Tea became the domestic beverage, associated with women and home
- Eventually, tea won out in Britain due to colonial ties with India and China
- Coffee remained dominant in continental Europe

## Colonial Expansion and Coffee Plantations (17th-18th Centuries)

### The Dutch Coffee Empire

The Dutch were instrumental in spreading coffee cultivation worldwide:

**Java (1696)**
- Dutch Governor Nicolaes Witsen brought coffee plants to Java
- Dutch East India Company established vast plantations
- "Java" became synonymous with coffee
- Developed forced cultivation systems (*cultuurstelsel*)

**Ceylon (Sri Lanka) and India**
- Coffee introduced in 1658
- Major producer until coffee rust devastated crops in 1869
- Switched to tea cultivation afterward

**Caribbean and Americas**
- Dutch brought coffee to Suriname (1718)
- Spread to French and British colonies

### The French Coffee Connection

**Martinique and the Caribbean (1720s)**
- Gabriel de Clieu, a French naval officer, brought a single coffee plant from Paris to Martinique in 1720
- Despite attacks by pirates, storms, and a jealous passenger who tried to destroy it, the plant survived
- This single plant became the progenitor of most coffee in the Caribbean and Central/South America
- Within 50 years, Martinique had 19 million coffee trees

**Bourbon Island (Réunion)**
- French established coffee plantations (1715)
- Bourbon variety developed here, still grown worldwide
- Important genetic source for coffee breeding

### Brazil: The Coffee Superpower Emerges

**The Smuggled Seeds (1727)**
- Portuguese brought coffee to Brazil in 1727
- Legend says Francisco de Mello Palheta seduced the wife of French Guiana's governor to obtain coffee seeds (which French guarded jealously)
- She gave him a bouquet with coffee cuttings hidden inside

**Brazilian Coffee Boom (19th Century)**
- Perfect climate and soil in southeastern Brazil
- Massive expansion using slave labor until 1888
- By 1850, Brazil produced 50% of world's coffee
- Coffee became Brazil's economic foundation ("Coffee is São Paulo's gold")
- Built vast fortunes for coffee barons (*fazendeiros*)

## The Age of Coffee (18th-19th Centuries)

### Coffee and the American Revolution

Coffee became America's drink partly due to politics:
- The **Boston Tea Party** (1773) made tea politically unacceptable
- Switching to coffee became a patriotic act
- American coffee culture diverged from European café tradition
- Emphasis on quantity and convenience over café culture

### Coffee and Slavery

The dark side of coffee expansion:
- Caribbean, Brazilian, and Colombian plantations relied heavily on enslaved labor
- Millions of Africans enslaved in the coffee trade
- Harsh working conditions and high mortality rates
- Economic model based on exploitation continued even after formal abolition

### Industrial Coffee Processing

**19th Century Innovations:**
- **1818**: First coffee percolator invented by Parisian tinsmith
- **1864**: Jabez Burns invented commercial coffee roaster
- **1901**: Luigi Bezzera invented espresso machine
- **1908**: Melitta Bentz invented paper coffee filter
- **1938**: Nestlé introduced instant coffee (Nescafé)

## The 20th Century: Industrialization and Commodity Trading

### The First Wave: Mass Market Coffee (1800s-1960s)

**Vacuum Packaging and Canned Coffee**
- Hills Bros. pioneered vacuum packaging (1900)
- Made coffee a shelf-stable grocery item
- Folgers, Maxwell House became household names
- Emphasis on consistency and affordability over quality

**Instant Coffee Revolution**
- Became essential military ration in WWII
- GIs brought taste for instant coffee home
- Nescafé dominated global market
- Coffee became a commodity, not a craft

**Coffee Becomes a Global Commodity**
- International Coffee Organization formed (1963)
- Price controls and quota systems
- Coffee traded on futures markets
- Quality often sacrificed for yield and price

### Coffee Crises and International Politics

**Coffee Rust (1869-1920s)**
- *Hemileia vastatrix* fungus devastated Asian coffee
- Ceylon (Sri Lanka) switched from coffee to tea
- Led to development of resistant varieties
- Changed global coffee geography

**The International Coffee Agreement (1962-1989)**
- Regulated coffee prices through quotas
- Collapsed in 1989, causing price crash
- Many farmers forced into poverty
- Led to quality decline as farmers prioritized quantity

**The Coffee Crisis (1990s-2000s)**
- Oversupply and price collapse
- Coffee farmers earning below cost of production
- Led to migration, poverty, child labor issues
- Spurred Fair Trade and Direct Trade movements

### The Second Wave: Café Culture (1960s-1990s)

**Peet's Coffee (1966)**
- Alfred Peet opened in Berkeley, California
- Emphasized dark roasts and quality beans
- Trained Jerry Baldwin, Zev Siegl, and Gordon Bowker
- These three went on to found Starbucks (1971)

**Starbucks Expansion (1980s-present)**
- Started as small Seattle roaster (1971)
- Howard Schultz joined (1982), became CEO (1987)
- Introduced Italian-style espresso drinks to America
- Rapid global expansion in 1990s-2000s
- Created "third place" between home and work
- Made coffee a lifestyle brand

**Café Culture Renaissance**
- European-style cafés in America
- Espresso drinks became mainstream
- Coffee as social experience, not just caffeine
- Rise of coffee chains globally

## The Third Wave: Specialty Coffee (1990s-present)

### Philosophy and Principles

The Third Wave treats coffee like wine:
- Coffee as an artisanal food product
- Emphasis on origin, variety, processing
- Transparent supply chains
- Direct relationships with farmers
- Light roasts to highlight origin characteristics
- Precision brewing methods

### Key Innovators

**Counter Culture (1995, Durham, NC)**
- Direct Trade pioneer
- Transparency in sourcing and pricing
- Coffee education programs
- B Corporation certified

**Intelligentsia (1995, Chicago)**
- Direct Trade program
- Published pricing paid to farmers
- Multiple sourcing trips per year
- Barista training and education

**Stumptown (1999, Portland)**
- Popularized light roasts
- Direct Trade model
- Cold brew innovation
- Craft coffee aesthetic

**Blue Bottle (2002, Oakland)**
- Founded by James Freeman
- Emphasis on freshness (coffee within 48 hours of roasting)
- Japanese-inspired precision
- Acquired by Nestlé for $700M (2017)

### The Science of Coffee

**Specialty Coffee Association (SCA)**
- Created cupping protocols and scoring system
- Q Grader certification program
- Coffee scored on 100-point scale (80+ is "specialty grade")
- Standardized brewing parameters

**World Barista Championship**
- Started 2000, showcasing coffee preparation as art
- Elevated barista profession
- Innovation in brewing and serving
- Global coffee community building

**Coffee Science Advances**
- Understanding of extraction chemistry
- Precise measurement (refractometers)
- Water chemistry and coffee
- Fermentation science in processing
- Climate impact research

## Modern Coffee Culture (21st Century)

### Fourth Wave? (2010s-present)

Some argue we're entering a Fourth Wave:
- Coffee as agricultural product and science
- Sustainability and climate focus
- Experimental processing methods
- Exotic varieties and rare coffees
- Technology integration (apps, precision equipment)
- Consumer education and home brewing

### Geisha/Gesha Phenomenon

**2004 Hacienda La Esmeralda Auction**
- Panamanian Geisha coffee sold for $21/pound
- Record broken repeatedly in subsequent years
- 2019: $1,029/pound at Best of Panama auction
- 2023: $10,013/pound (single lot record)
- Transformed specialty coffee economics
- Proved consumers would pay for exceptional quality

### Specialty Coffee Expansion

**Global Reach**
- Third wave culture in Asia (Japan, South Korea, Taiwan)
- Scandinavian coffee culture (light roasts, filter coffee)
- Australian flat white goes global
- Specialty coffee in producing countries (Colombia, Ethiopia)

**Home Brewing Revolution**
- Pour-over devices (V60, Chemex, Kalita Wave)
- Precision scales and thermometers
- Home espresso machines ($500-$3000+)
- Coffee subscription services
- Home roasting equipment

### Ethical and Environmental Movements

**Fair Trade Certification (1988)**
- Minimum prices for farmers
- Community development premiums
- Environmental standards
- Worker protections

**Direct Trade (2000s)**
- Roasters buy directly from farmers
- Higher prices than Fair Trade
- Relationship-based sourcing
- Transparency in pricing

**Organic Certification**
- Pesticide-free farming
- Soil health focus
- Biodiversity preservation
- Often combined with Fair Trade

**Rainforest Alliance**
- Environmental sustainability
- Wildlife habitat protection
- Worker welfare standards
- Climate resilience

**Carbon Neutrality and Climate**
- Climate-neutral roasting
- Carbon offset programs
- Shipping innovations
- Compostable packaging

### Coffee and Climate Change

**Threats to Coffee Production**
- Rising temperatures reducing suitable land
- Increased pests and diseases
- Changing rainfall patterns
- Coffee rust spreading to new regions
- Arabica particularly vulnerable

**Industry Response**
- Development of climate-resistant varieties
- World Coffee Research organization
- Agroforestry and shade-grown coffee
- Migration to higher altitudes
- Diversification of income sources

## Coffee Around the World: Regional Cultures

### Italian Coffee Culture

**The Espresso Tradition**
- Espresso is the foundation: quick, strong, at the bar
- Cappuccino only before 11 AM (never after meals)
- Macchiato: espresso with a touch of milk
- Caffè latte is a breakfast drink
- Standing at the bar (sitting costs more)
- Social ritual, not lingering

### Scandinavian Coffee Culture

**Fika (Sweden) and Hygge (Denmark)**
- Coffee as social break, often with pastries
- Per capita coffee consumption among world's highest
- Light roasts preferred
- Filter coffee, not espresso
- Coffee as life quality, not just caffeine

### Turkish and Middle Eastern Coffee

**Traditional Preparation**
- Finely ground coffee boiled in *cezve* (ibrik)
- Served in small cups with grounds
- Sugar added during brewing, not after
- Fortune telling from coffee grounds (*tasseography*)
- Coffee ceremony as hospitality ritual

### Ethiopian Coffee Ceremony

**Sacred Ritual**
- Roasting green beans over charcoal
- Grinding by hand with mortar and pestle
- Brewing in *jebena* (clay pot)
- Served in three rounds: *abol*, *tona*, *baraka*
- Incense, popcorn, and conversation
- Can last 2-3 hours, social bonding

### Vietnamese Coffee Culture

**Cà Phê Sữa Đá**
- Robusta coffee, very strong
- Brewed through phin filter (slow drip)
- Sweetened condensed milk
- Served over ice
- Street café culture on tiny stools
- Egg coffee (cà phê trứng) in Hanoi

### Australian Coffee Culture

**Flat White Revolution**
- Created in Australia/New Zealand (1980s)
- Microfoam milk, espresso-forward
- Coffee quality obsession
- Artisanal roasting culture
- Influenced global coffee standards
- Resisted Starbucks (most stores closed)

### Japanese Coffee Precision

**Kissaten and Pour-Over**
- Traditional kissaten (coffee houses) since early 1900s
- Meticulous brewing techniques
- Siphon brewing as theater
- Single-origin pour-over
- Iced coffee perfection
- Respect for craft and ritual

## Coffee Economics and Statistics

### Global Production
- **10-11 million tons** produced annually
- **125 million people** depend on coffee for income
- Grown in **70+ countries** (coffee belt: 25°N to 30°S)
- **Brazil** #1 producer (40% of world supply)
- **Vietnam** #2 (mainly Robusta)
- **Colombia** #3 (100% Arabica)

### Consumption
- **2.25 billion cups** consumed daily worldwide
- **Finland** highest per capita (12kg/person/year)
- **USA** largest consumer by volume (400M cups/day)
- **Europe** consumes 30% of global coffee

### Economic Impact
- **$100+ billion** global coffee industry
- **$200+ billion** including retail and cafés
- Second most traded commodity after oil (disputed)
- Coffee futures traded on ICE exchange

## Coffee Varieties: The Plant Science

### Coffea Arabica (60-70% of production)
- Originated in Ethiopian highlands
- Self-pollinating
- Complex flavors, higher acidity
- More expensive, considered superior
- Vulnerable to pests and disease
- Grows 1000-2000+ meters altitude

### Coffea Canephora (Robusta, 30-40%)
- Originated in Central and West Africa
- Cross-pollinating
- Bitter, higher caffeine (2x Arabica)
- Hardier, disease-resistant
- Lower price point
- Grows at lower altitudes

### Rare Species
- **Coffea Liberica**: Large beans, asymmetrical, strong taste
- **Coffea Excelsa**: Now classified as Liberica variant
- Less than 1% of global production combined

## Coffee Processing Methods

### Natural/Dry Process (Traditional)
- Coffee cherries dried whole in sun
- Fruit ferments around bean
- Fruity, wine-like flavors
- Less water needed
- Higher risk of defects
- Common in Ethiopia, Brazil

### Washed/Wet Process (Modern)
- Fruit removed before drying
- Beans fermented to remove mucilage
- Clean, bright, acidic profile
- Requires significant water
- More consistent quality
- Common in Central America, Kenya

### Honey/Pulped Natural
- Partial fruit removal
- Varying levels (white, yellow, red, black honey)
- Sweetness and body of natural, clarity of washed
- Water-saving alternative
- Common in Costa Rica

### Experimental Processing
- Anaerobic fermentation
- Carbonic maceration (wine technique)
- Koji fermentation (Japanese)
- Extended fermentation
- Controlled temperature processing
- Creating exotic flavor profiles

## The Future of Coffee

### Challenges Ahead
- Climate change reducing suitable land by 50% by 2050
- Aging coffee farmer population
- Price volatility hurting farmers
- Disease and pest pressure
- Water scarcity in producing regions

### Innovations and Solutions
- **F1 Hybrid Varieties**: Higher yields, disease resistance, climate adapted
- **Gene Editing**: CRISPR for disease resistance
- **Vertical Farming**: Indoor coffee cultivation experiments
- **Lab-Grown Coffee**: Cellular agriculture, still early stage
- **Blockchain**: Supply chain transparency
- **Precision Agriculture**: Sensors, drones, data analytics

### Sustainability Initiatives
- Regenerative agriculture practices
- Carbon-positive farming
- Agroforestry systems
- Water conservation techniques
- Circular economy in coffee waste
- Living income initiatives for farmers

## Conclusion

From Ethiopian forests to global commodity, from religious controversy to daily necessity, coffee's journey spans continents and centuries. It has fueled revolutions, inspired art, built empires, and connected cultures.

Today's coffee industry stands at a crossroads: between mass commodity and artisanal craft, between exploitation and fair trade, between tradition and innovation. As climate change threatens production, the industry must evolve to ensure coffee's future—for the planet, for farmers, and for the billions who can't imagine a day without it.

The story of coffee is far from over. Each cup connects us to this remarkable history—and to the ongoing story being written by farmers, roasters, baristas, and drinkers around the world.

---

*"Coffee is a language in itself."* — Jackie Chan
