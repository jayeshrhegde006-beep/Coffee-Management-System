![Roast & Revel Background](app_background.png)

# Complete Coffee Guide

## Coffee Species

### Coffea Arabica
**60-70% of global production**

The original and most prized coffee species, Arabica originated in the Ethiopian highlands. Known for its complex flavors, delicate acidity, and aromatic qualities.

**Characteristics:**
- Smooth, complex flavor with pleasant acidity
- Lower caffeine content (0.8-1.4%)
- Grows at high altitudes (1000-2000+ meters)
- Self-pollinating
- More susceptible to disease and pests
- Requires specific climate conditions

**Flavor Profile:** Sweet, fruity, with notes of berries, chocolate, nuts, and caramel

**Growing Conditions:** Prefers cool subtropical climates, abundant rainfall, and rich soil

---

### Coffea Canephora (Robusta)
**30-40% of global production**

Discovered in the Congo Basin, Robusta is hardier and more productive than Arabica. Often considered inferior in taste but essential for espresso blends and instant coffee.

**Characteristics:**
- Strong, harsh, bitter flavor
- Higher caffeine content (1.7-4.0%)
- Grows at lower altitudes (0-800 meters)
- Cross-pollinating
- Disease and pest resistant
- Tolerates warmer climates

**Flavor Profile:** Earthy, grainy, bitter with notes of peanuts and dark chocolate

**Uses:** Espresso blends (adds crema), instant coffee, Vietnamese coffee

---

### Coffea Liberica
**Less than 1% of production**

A rare species with large, irregular beans. Mostly grown in the Philippines and Malaysia.

**Characteristics:**
- Unique fruity, woody, smoky flavor
- Very large, asymmetrical beans
- Distinctive aroma (sometimes described as "different")
- Hardy plant, disease resistant

**Flavor Profile:** Fruity, floral, smoky, woody, sometimes polarizing

---

## Major Coffee-Producing Regions

### Africa

#### Ethiopia - The Birthplace
- **Yirgacheffe**: Floral, tea-like, bergamot, lemon
- **Sidamo**: Berry, wine-like, chocolate, spice
- **Harrar**: Wild blueberry, wine, mocha
- **Processing**: Natural and washed methods
- **Altitude**: 1500-2200m
- **Harvest**: October-January

#### Kenya - The Bright Star
- **Kenya AA**: Blackcurrant, grapefruit, wine-like, tomato
- **Varietals**: SL28, SL34, Ruiru 11
- **Processing**: Washed, double fermentation
- **Altitude**: 1400-2000m
- **Harvest**: October-December, May-July

#### Rwanda - The Rising Star
- **Bourbon Varietals**: Citrus, floral, red fruit
- **Processing**: Fully washed
- **Quality**: Rapidly improving specialty market
- **Altitude**: 1700-2000m

---

### Central America

#### Guatemala - The Complex
- **Antigua**: Chocolate, spice, smoke, floral
- **Huehuetenango**: Fruit, wine, chocolate, floral
- **Volcanic Soil**: Contributes to complexity
- **Altitude**: 1500-2000m
- **Harvest**: December-March

#### Costa Rica - The Clean
- **Tarrazú**: Chocolate, citrus, honey, clean
- **Wet Processing**: Fully washed tradition
- **Quality Focus**: High standards, no Robusta allowed
- **Altitude**: 1200-1900m
- **Harvest**: November-March

#### Panama - The Elite
- **Geisha/Gesha**: Jasmine, bergamot, tropical fruit, tea-like
- **Record Prices**: $10,000+ per pound at auction
- **Boquete Region**: Prime Geisha production
- **Altitude**: 1400-1900m

---

### South America

#### Colombia - The Balanced
- **Huila**: Caramel, tropical fruit, citrus
- **Nariño**: Orange, honey, floral, bright
- **Supremo Grade**: Largest bean size
- **Altitude**: 1200-2000m
- **Two Harvests**: Main (Sep-Dec), Mitaca (Apr-Jun)

#### Brazil - The Giant
- **Santos**: Chocolate, peanuts, caramel, low acidity
- **Cerrado**: Chocolate, caramel, hazelnut, sweet
- **Natural Processing**: Traditional method
- **Altitude**: 600-1300m
- **Volume**: 40% of world production

#### Peru - The Organic
- **Chanchamayo**: Chocolate, nuts, citrus, balanced
- **Organic Focus**: Large organic production
- **Processing**: Washed
- **Altitude**: 1000-1800m

---

### Asia & Pacific

#### Indonesia - The Earthy
- **Sumatra Mandheling**: Earth, cedar, herbs, chocolate
- **Java**: Earthy, spicy, chocolate
- **Sulawesi Toraja**: Earthy, dark fruit, spice
- **Wet-Hulled Processing**: Unique to Indonesia
- **Altitude**: 750-1800m

#### Yemen - The Ancient
- **Mocha**: Wine, chocolate, spice, wild berry
- **Terraced Farms**: Traditional methods
- **Natural Processing**: Dry method
- **Historical Significance**: First commercial cultivation

#### Hawaii - The Premium
- **Kona**: Smooth, sweet, nutty, mild
- **100% Kona**: Expensive, limited production
- **Typica Varietal**: Traditional variety
- **Altitude**: 150-900m

#### Vietnam - The Robusta King
- **Robusta Dominant**: 97% Robusta production
- **Cà Phê Sữa**: Coffee with condensed milk
- **Phin Filter**: Traditional brewing
- **Volume**: 2nd largest producer globally

---

## Coffee Processing Methods

### Natural/Dry Process
**Traditional Method**

The coffee cherries are dried whole in the sun, with the fruit intact around the bean.

**Process:**
1. Harvest ripe cherries
2. Spread on drying beds/patios
3. Turn regularly for 3-4 weeks
4. Remove dried fruit (hulling)

**Flavor:** Fruity, sweet, wine-like, full body
**Regions:** Ethiopia, Brazil, Yemen
**Pros:** Less water, fruity complexity
**Cons:** Risk of fermentation defects, weather-dependent

---

### Washed/Wet Process
**Modern Method**

The fruit is removed from the beans before drying, creating a cleaner cup.

**Process:**
1. Harvest and sort cherries
2. Remove skin and pulp (depulping)
3. Ferment to remove mucilage (12-48 hours)
4. Wash thoroughly
5. Dry parchment coffee

**Flavor:** Clean, bright, acidic, clear origin characteristics
**Regions:** Central America, Kenya, Colombia
**Pros:** Consistent quality, bright flavors
**Cons:** Water intensive, requires infrastructure

---

### Honey/Pulped Natural
**Hybrid Method**

Partial fruit removal, leaving some mucilage on the bean during drying.

**Variations:**
- **White Honey**: 80-90% mucilage removed
- **Yellow Honey**: 50-75% removed
- **Red Honey**: 25-50% removed
- **Black Honey**: 0-25% removed

**Flavor:** Sweet, balanced, fruity body with clean finish
**Regions:** Costa Rica, El Salvador
**Pros:** Water-saving, unique sweetness
**Cons:** Requires careful drying management

---

### Wet-Hulled (Giling Basah)
**Indonesian Method**

Unique to Indonesia, beans are hulled while still wet, creating distinctive flavors.

**Process:**
1. Remove skin and pulp
2. Brief fermentation
3. Partial drying (30-35% moisture)
4. Hull while still wet
5. Final drying

**Flavor:** Earthy, herbal, full body, low acidity
**Regions:** Sumatra, Sulawesi
**Pros:** Faster processing in humid climate
**Cons:** Risk of defects if not done carefully

---

## Roast Levels

### Light Roast
**City Roast, Cinnamon Roast**
- **Color:** Light brown, no oil on surface
- **Temperature:** 356-401°F (180-205°C)
- **Acidity:** High, bright
- **Body:** Light to medium
- **Flavors:** Preserved origin characteristics, fruity, floral, tea-like
- **Best For:** Single-origin, pour over, filter coffee

### Medium Roast
**American Roast, City+ Roast**
- **Color:** Medium brown, rarely oily
- **Temperature:** 410-428°F (210-220°C)
- **Acidity:** Moderate, balanced
- **Body:** Medium, rounded
- **Flavors:** Balanced, sweet, caramel, nuts, chocolate
- **Best For:** Drip coffee, everyday brewing

### Medium-Dark Roast
**Full City Roast, Vienna Roast**
- **Color:** Dark brown, slight oil sheen
- **Temperature:** 437-446°F (225-230°C)
- **Acidity:** Low
- **Body:** Full, rich
- **Flavors:** Bittersweet, caramel, chocolate, roast character
- **Best For:** Espresso, French press

### Dark Roast
**French Roast, Italian Roast**
- **Color:** Very dark, oily surface
- **Temperature:** 464-482°F (240-250°C)
- **Acidity:** Very low or none
- **Body:** Very full, heavy
- **Flavors:** Smoky, bitter, charred, roast dominates origin
- **Best For:** Espresso, milk-based drinks

---

## Brewing Methods Guide

### Espresso
**Pressure Extraction**
- **Grind:** Fine
- **Water:** 195-205°F (90-96°C)
- **Time:** 25-30 seconds
- **Ratio:** 1:2 (18g → 36g)
- **Pressure:** 9 bars
- **Result:** Concentrated, intense, crema

### Pour Over (V60, Chemex)
**Manual Filter**
- **Grind:** Medium-fine to medium
- **Water:** 195-205°F (90-96°C)
- **Time:** 2.5-4 minutes
- **Ratio:** 1:15-1:17
- **Technique:** Controlled pouring in stages
- **Result:** Clean, bright, highlights origin

### French Press
**Immersion**
- **Grind:** Coarse
- **Water:** 195-205°F (90-96°C)
- **Time:** 4 minutes
- **Ratio:** 1:15
- **Technique:** Steep and plunge
- **Result:** Full body, oils, some sediment

### AeroPress
**Versatile Pressure**
- **Grind:** Fine to medium
- **Water:** 175-185°F (80-85°C)
- **Time:** 1-2 minutes
- **Ratio:** 1:15-1:17
- **Technique:** Multiple methods possible
- **Result:** Clean to full, adaptable

### Cold Brew
**Long Immersion**
- **Grind:** Coarse
- **Water:** Room temperature or cold
- **Time:** 12-24 hours
- **Ratio:** 1:8 (for concentrate)
- **Technique:** Steep in fridge or room temp
- **Result:** Smooth, sweet, low acidity

---

## Coffee Cupping & Tasting

### SCA Cupping Protocol
Professional coffee tasting follows strict standards:

**Setup:**
- 8.25g coffee per 150ml water
- Medium-coarse grind
- Water at 200°F (93°C)
- 6 cups per coffee sample

**Process:**
1. **Dry Fragrance:** Smell ground coffee
2. **Wet Aroma:** Smell coffee after adding water
3. **Break Crust:** Push grounds down after 4 minutes
4. **Skim:** Remove foam and floating grounds
5. **Taste:** Slurp coffee from spoon at various temperatures

**Scoring (100 points):**
- Fragrance/Aroma (10)
- Flavor (10)
- Aftertaste (10)
- Acidity (10)
- Body (10)
- Balance (10)
- Uniformity (10)
- Clean Cup (10)
- Sweetness (10)
- Overall (10)

**Grades:**
- **90-100:** Outstanding (Exceptional)
- **85-89.99:** Excellent (Specialty)
- **80-84.99:** Very Good (Premium)
- **Below 80:** Commercial grade

---

## Flavor Wheel Components

### Primary Tastes
- **Sweet:** Honey, caramel, maple, brown sugar
- **Sour/Acid:** Citric, malic, tartaric
- **Salty:** Rarely present, processing artifact
- **Bitter:** Dark chocolate, roast character
- **Umami:** Savory notes (rare)

### Aroma Categories
**Enzymatic (light roast):**
- Floral: Jasmine, rose, chamomile
- Fruity: Berry, citrus, stone fruit, tropical
- Herbal: Tea-like, grass, fresh

**Sugar Browning (medium roast):**
- Nutty: Almond, hazelnut, peanut
- Caramelly: Caramel, honey, maple
- Chocolatey: Dark chocolate, cocoa, milk chocolate

**Dry Distillation (dark roast):**
- Resinous: Pine, cedar, medicinal
- Spicy: Cinnamon, clove, pepper
- Carbony: Ashy, smoky, burnt

---

## Coffee Storage Tips

### Whole Beans
- **Container:** Airtight, opaque
- **Location:** Cool, dark, dry
- **Duration:** 2-4 weeks peak freshness
- **Freezing:** Acceptable for long-term (1-2 months), in airtight bags
- **Avoid:** Heat, light, moisture, air

### Ground Coffee
- **Freshness:** Use within 1-2 weeks
- **Degradation:** Much faster than whole beans
- **Recommendation:** Grind just before brewing
- **Storage:** Same as whole beans but more critical

### Green (Unroasted) Coffee
- **Duration:** 1-2 years if stored properly
- **Conditions:** Cool, dry, low humidity
- **Container:** Burlap or GrainPro bags
- **Purpose:** For home roasters

---

## Coffee & Health

### Potential Benefits
- **Antioxidants:** High in chlorogenic acids
- **Mental Alertness:** Caffeine enhances focus
- **Physical Performance:** Increases adrenaline
- **Metabolism:** May boost metabolic rate
- **Disease Prevention:** Linked to lower risk of type 2 diabetes, Parkinson's, liver disease

### Considerations
- **Caffeine Sensitivity:** Varies by individual
- **Sleep Disruption:** Avoid 6 hours before bed
- **Anxiety:** Can exacerbate in sensitive individuals
- **Pregnancy:** Limit to 200mg caffeine per day
- **Acid Reflux:** May trigger in some people

### Caffeine Content
- **Espresso:** 63mg per shot (1 oz)
- **Drip Coffee:** 95-200mg per 8 oz cup
- **French Press:** 80-135mg per 8 oz
- **Cold Brew:** 150-240mg per 8 oz (concentrate)
- **Instant:** 30-90mg per 8 oz

---

## Sustainable & Ethical Coffee

### Certifications

**Fair Trade**
- Minimum price guarantee for farmers
- Community development premiums
- Democratic organization required
- Environmental standards

**Organic**
- No synthetic pesticides or fertilizers
- Soil health focus
- Biodiversity preservation
- 3-year transition period

**Rainforest Alliance**
- Environmental protection
- Wildlife conservation
- Worker welfare
- Climate resilience

**Direct Trade**
- Roaster-farmer relationships
- Premium prices above Fair Trade
- Quality incentives
- Transparency in pricing

### Environmental Impact

**Coffee Production Issues:**
- Deforestation for plantations
- Water pollution from processing
- Pesticide use
- Climate change vulnerability

**Sustainable Practices:**
- Shade-grown coffee (bird-friendly)
- Agroforestry systems
- Water conservation
- Organic farming
- Carbon-neutral shipping

---

## Coffee Myths & Facts

### Myth: Dark Roast Has More Caffeine
**Fact:** Light roast actually has slightly more caffeine by volume. Roasting burns off caffeine. However, measuring by weight, they're nearly equal.

### Myth: Espresso Is the Strongest Coffee
**Fact:** Espresso is the most concentrated, but drip coffee has more total caffeine per serving due to larger volume.

### Myth: Coffee Stunts Growth
**Fact:** No scientific evidence supports this. Moderate coffee consumption is safe for adolescents.

### Myth: Coffee Dehydrates You
**Fact:** While caffeine is a mild diuretic, coffee contributes to daily fluid intake. The water content offsets diuretic effect.

### Myth: Coffee Should Be Stored in the Fridge
**Fact:** Room temperature in airtight container is best. Fridge introduces moisture and odors. Freezer is okay for long-term storage in airtight bags.

### Myth: Expensive Equals Better
**Fact:** Price reflects rarity and quality, but personal preference matters. A $15 coffee might not taste "better" to you than a $10 one.

---

## Coffee Terminology

**Acidity:** Brightness, liveliness (not sour). Desirable in specialty coffee.

**Aroma:** Fragrance of brewed coffee.

**Body:** Weight or texture in mouth (light, medium, full).

**Crema:** Tan foam on espresso from oils and CO2.

**Cupping:** Professional tasting method.

**Defect:** Flaw in coffee bean (quaker, sour, phenolic).

**Extraction:** Process of dissolving compounds from coffee into water.

**First Crack:** Audible pop during roasting (light-medium roast).

**Second Crack:** Quieter cracking (dark roast, oils emerge).

**Green Coffee:** Unroasted coffee beans.

**Peaberry:** Single round bean (usually two flat beans per cherry).

**Pull:** Extract an espresso shot.

**Quaker:** Unripe bean that didn't roast properly.

**Tamp:** Compress ground espresso in portafilter.

**Terroir:** Environmental factors affecting flavor (soil, altitude, climate).

---

*"I'd rather take coffee than compliments just now."* — Louisa May Alcott
